/*
Copyright 2020. Huawei Technologies Co., Ltd. All rights reserved.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
 */
 
<?php
 
$url="https://oauth-login.cloud.huawei.com/oauth2/v3/tokeninfo"; //Request address

$param = array(
    "id_token" => "eyJraWQiOiIzMWNmN2Q0M2UxMmQ3ZWMxMDFmY2NjYmQ3NTFlNmJlN2U2NDQ5NmRhYmUyZmUyODUxN2Q3ZmZhYjM5YzFkM2VlIiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ.eyJhdF9oYXNoIjoiSDdHZldaUTFLQ2w1MHdvdjFYR3NRdyIsImF1ZCI6IjEwMTM0NzM0NyIsInN1YiI6Ik1ER1ltMjlObjhIbXE3bkphS0JmTjdZWnNpYzhzTjBUYVh0blppYTJRRVp4TERQdyIsImF6cCI6IjEwMTM0NzM0NyIsImlzcyI6Imh0dHBzOi8vYWNjb3VudHMuaHVhd2VpLmNvbSIsImV4cCI6MTU3NjUwNjc0NCwiZGlzcGxheV9uYW1lIjoi546L5rSqIiwiaWF0IjoxNTc2NTAzMTQ0LCJub25jZSI6IjAzOTQ4NTItMzE5MDQ4NS0yNDkwMzU4In0.ASpja2lwYodTWHceYFc4tNJgYvRWWJIURoKp34v96bhsC1mpYRsV_YDZ0r2Lur9I80D_ddqojPqifNtR4esIOeB3nPo-eTK9mBac3fLGgECr-9BYLKq3Ju186nwxbBwgR4aMjzmSWQGsgElFO62_eR2dLm7XupRHWOBfWV4nJT8aE0Y53vVSuk9vEfhcEq8pwgWpTSZn26E027IhG0ssYxDd-dB_2K2pSKfO2MbAI4685sHZIKnB7P7605IJHYLB_9NdjCTEfE1DHubCmrSfkzlaQjjEZZ3sD9lrpo0Z1_ZLxbZg-KE_G6H3wsnHQVTmPDobS10CUSqk0qyPuGB1DQ",
   );

    $ch = curl_init();
    $header[] = "Content-Type: application/x-www-form-urlencoded";
    $content = http_build_query($param, "", "&");
    $header[] = "Content-Length: ".strlen($content);   
    curl_setopt($ch, CURLOPT_HEADER, true); //setting output include header
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header); //setting the transferred content in the header
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, count($param));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // check the source of the certificate or not
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); // check the source of the certificate or not
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // setting not automatically output content, even faild
    $response = curl_exec($ch);

    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $result = substr($response, $header_size);
    curl_close($ch);
	echo 'return result:'.$result;
?>
