/*
Copyright 2020. Huawei Technologies Co., Ltd. All rights reserved.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
 */
 
<?php

$url="https://api.cloud.huawei.com/rest.php?nsp_fmt=JSON&nsp_svc=huawei.oauth2.user.getTokenInfo"; //Request address

$param = array(
    "open_id" => "OPENID",
    "access_token" => "CV33lXjzd/ESxzDuuBDNPzzJ+HzKRaGaYpW+pPNPQVS1s4IzXHI5t3SOTcM+wN3S26ghbWvRZVoIWo42QYQi+t4i+k3McMi1Wqp11tWh19EcU9CG4GXDv58ZDEI=",   
    );
	
    $ch = curl_init();
    $header[] = "Content-Type: application/x-www-form-urlencoded";
    $content = http_build_query($param, "", "&");
    $header[] = "Content-Length: ".strlen($content);  
    curl_setopt($ch, CURLOPT_HEADER, true);	 //setting output include header.
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header); //setting the transferred content in the header.
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, count($param));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $content);  
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // check the source of the certificate or not.
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); // check the source of the certificate or not.
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // setting not output all content if faild automatically.
    $response = curl_exec($ch);

    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $result = substr($response, $header_size);
    curl_close($ch);
	echo 'return result:'.$result;
	
?>
