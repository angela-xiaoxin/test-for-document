/*
Copyright 2020. Huawei Technologies Co., Ltd. All rights reserved.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
 */
 
<?php

$url="https://oauth-login.cloud.huawei.com/oauth2/v3/token"; //Request address

$param = array(
    //set value as "authorization_code"；meaning Use Authorization Code to get Access Token and ID Token.
    "grant_type" => "authorization_code",
	//Appid of the application registered on the developer Alliance.
    "client_id" => "101347347",   
	//Public key assigned to the application which created in developer alliance,please refrencing the interface description for using.
    //"client_secret" => "701e47383e6a108f86c9c05325fa8e6e",  
	//Random number which used for verify the code,please refrencing the interface description for using.
    "code_verifier" => "123444444dfd4sadfsdwew321454567587658776t896fdfgdscvvbfxdgfdgfdsfasdfsdgd233", 
	//Callback url of application configuration.
    "redirect_uri" => "https://www.example.com",
    "code"=>"DF33iGmHUG/MqgtF7Zl7ZoG3eUd+ep7rY8LD4MhA7nOdkE/6RwmB/tj1IBlvejal4yc3OBrUhFuXS1+89kCIzrDMW5e1kiWg5tU/xP0m5uD+jhE0rZ7yt1VXsznaq9TRSFwL2kM1s58ePJ6BDyjD4TMstrPMKCwSbL5Urw9DDQiem8YNuzulG6XeF6EN6WZxneXtkqErfXEzyiznZSI3vxMidheg9AQ1hu6BJiBu6pA/d//E5QvZzDVN0XkXVqMKy28EmJ57e+sNn/YCke+ZrpcPRxdZCstTljL7kNzcX2LpgnlEAA=="
    );



    $ch = curl_init();     
    $header[] = "Content-Type: application/x-www-form-urlencoded";
    $content = http_build_query($param, "", "&");


    $header[] = "Content-Length: ".strlen($content);
    curl_setopt($ch, CURLOPT_HEADER, true); //setting output include header.
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header); //setting the transferred content in the header.
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, count($param));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // check the source of the certificate or not.
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); // check the source of the certificate or not.
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // setting not output all content if faild automatically
	$response = curl_exec($ch);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $result = substr($response, $header_size);
    curl_close($ch);
	
	echo 'return result:'.$result;
?>
