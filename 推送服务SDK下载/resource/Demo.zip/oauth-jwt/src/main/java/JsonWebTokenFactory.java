/*
Copyright 2020. Huawei Technologies Co., Ltd. All rights reserved.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
 */
import java.nio.charset.Charset;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import org.apache.commons.codec.binary.Base64;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator.Builder;
import com.auth0.jwt.algorithms.Algorithm;
/**
 * Function Description
 * This is a demo for create a JWT
 * The open source software depended by this demo may have vulnerabilities,
 * please refer to the open source software release website and update to
 * the latest version or replace it with other open source software.
 * Local validation is much more efficiently than by access the tokeninfo endpoint
 * You'd better learn more about the JWT for understanding this demo
 * See more about JWT in https://jwt.io/
 * @author j00449997
 * @since 2019-12-19
 */
public class JsonWebTokenFactory {
    private static Charset DEFAULT_CHARSET = Charset.forName("UTF-8");

    // please replace it with the private_key in your json file
    // this is the plain text in this demo, please encrypt the private key in your code, only get the string between '-----BEGIN PRIVATE KEY-----\n' and '\n-----END PRIVATE KEY-----\n'
    private static final String PRIVATE_KEY = "MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQCKw6kJKtCh7qmMvp1u1dI27z2TKZrPOzHbQaXO/Eez0AWZ2EN+ouF496R3pfo7fQXC1XOT/YTbVC4DNZwWSMA54fu3/AOCY9Zzyi46OKCJu8NsIlDPv9Hb4PVb0AP5SqnP7/YMvQXhlx6V1F7GL9NC9ygQhr48ffYFA/2vRL/MEMRo0E00IIUsb/BdM+ceWtNbbw21TgVquXaKZElesSUX5hU9pN7FprL51jOxCYG3CthGMDgopJuzUP6BiTBP0pueDT9w02ooxLP+748RBGr7DEC5+g8O+9YKb/uiMgFwVWI9q2Qr4SMJd4tz6YwjRwLGoAvhMyIiSq+L/VdC3Mvp9917EMGGolfYo7dYsjiIJbx6e9iZRJW9ZSZXqA+QsxeegdyjLwDcLC1rrS+91Qs9LKPYSoLgaAjRpl/VWkNP+4KT4DaGCHt6T/ESS8Cv6jWJRTvCpLVOBlbfQ/xjhBGGsWZ0bzvOu31s7BVmJKViIFmYLWvGf/FFngjwSP2dLyILjVr07p29P6c7f0CBMAUTBhuaJoTnljhZ8BKWv5stGUwtM48IrmzDw27SM8Wooith0wLVnureVDxfOKSX5SSwJXcilZ3RE3cDhNp2uI/+L4zok4nZzAHVSysOqC1pH9KFi8mnPz2rGdXvC/JmDp2Bv92avXpd4/BEA54d1/kA4wIDAQABAoICABBAsn+8YAtXZMxzVwUwThrZEqE18kfrav9/ROhlbBCHgOBwEBe5BCei+cR50EE/d3lGfu8KdpEp3unJUaragolFCrKV9eNDxk5xk9CF6We4cj8sFcL/eJkEVDiYuJ5uPE16kZsUWKf/hzmNUjxsRZZGVI76+TUkm7giq4fnyX8hR5/vJdvBI1f9FG4WMi+/+5lt/HEL3l6NsnCrJlzM6sdNz5cUxHLp/3R7vjoyHttNjd9Krok0Hnh2OBj79Iik5k0wyAly+bAkueBWNq+LkOwulzYxL6pVnNBEJXjt2nVJyuPmOylYiT4GnnLJG/zVyGFzRXDvCERz8vO2jI3sRoXIs6oVhdWU9Pjl3UGfuqghljXTPSsTjrWfngF+pxW+cm1yu0/9sqrGFTm/7uKM6YQ36jCTmvVjlu00teWYPwF/suRaEkchKe5gdz1lMpO9UUAimLBmLko25K6eajoD60Djfx3wvd2XlkIFAUbF6wdB3JVITpbY2qo4JEy1OqimCq4iO4n1hLv8Ux/s1N3nnt+rXqJLuTpTqEBytZuyVx0JS6NWNj2sQ3xgwgKvcSn5vbu5GDJSdmxWQNBMeyJMLOjplW7dyYbGkicb6CKEMdHv+q6uGpxbMq3esWN+uzKcbqUhowjcSedzOrjAEvO+W4mobdFGuEhQOhShxXROFHWBAoIBAQDBfN3MgPtzkm2I94G03LQJq8Dwh7t94RzOUzLD9SY0S+CLpWQmZ5RBonUEgVfmQSa+fD2WIAaWdepiCYqR2wqc56zrmw3C97pUh8Bg/MiP25U4lfEDJtzDzsX7JeWiPrZs3pYrJlVi7eE7lYDqE+Wtt2ZWM+5A7ziC165VnhTMBoJmAQrgcqpgwpUmZam1IVrgW89x7J2f4TOueEt7g08vm7sBiBmhAJJc7cDls7s8qENlTXIqXmSaCtsxTjI4Yuo+ZwpvV2LSmV2W7LQweXmpnSvAXXtgmwOjt+Y8l9wL9uDi7B/AI5l02eocPoeYrbAzG44Ra0y+3wNttkxXukPRAoIBAQC3mK8aXcnsHjPqHnCA4m/IV/tDcgGjKS6V50A3derHGC9y7Ay0//xAdEplsR3m6pmmox5yXgPjkpwsWsA9P4ZhQpZ7QaZQaxXya2RyCWAWBCB6RwDCjPY5GMpXFXGJmhclcpv4LySWMqTLNCFJcwf1G1pdjx5NGSkpHZ57Mse66LQUOAYI4C9ACkLUfis9obVnkseO/b11p3RU4KaD5kMEv125HIyEg0ARC/VgFZ2GVsfBfPqDEJWWAL0U9qeZTnoL7+3jBumDq27D7pzmqMoZdZXYVT3PFfD1P5doSu8kF1sDCkTzeGS3dHuSVKAeLoRxsdnT5PGlDeN5sB7BuGpzAoIBAGItX8Xy9KQx+o5zOEdzbY8yrVXfKY23+gvfP3UbIWWL0sZJB8ZM7HdZXZMJpnZZPLWPCRjx6yXRczqHqN5VjM8M5zstlBAH724Q69bKrWIBg3gQ7RgyUfaxJthG5Hws4hff4cbHTrBCD/VR6PXdXr+EvdKjyxL7z2rk0brz2Y2lB+mGQeSdikJKua+gCjq0UA5jx6EA9QI5HSY8N+DWQgngNUWTr514UswAf86OIkWnA3uVjoZdGyLmu04LZYQi/MTpN+xDJQvDci+wr8Wg/dDIxXh4drAQOAqMt7CrRaZ0gKvkMEAoUCdwo0/tkpQwHaXxJ2dDUM/RDUZQJ/CjvOECggEAJ6mWem20h4vmzzcQOuewGmnXYDSq4eKtq7iviMuykpxI89zGyftbNVlqERn4ScB4vSUUGMTytiEgF/zq9tBYaX6HH82I7mqT7TECHBimZ1sw4Pmh0mW9c4xFehap1n4xbeeahj04/DGopDV403NETtE/7mJSu3kqCTXa3OaVe212KcAInbZAvub4lQtEsCXVGLD+54ctfNNWMFfv4SLHa6kjyC/As4ffOU+KDN3ej/0DXmtvew0EI8m5D2RRxK7NcvK8Q4VkwQsx/KX5w2LHdkSOwJN5rNkimvjH7sHxc6yP/tIjHy3tJCzH3U7m4F5QQneXhU06XtvnPoyruFHsvQKCAQEAndXTBCuadeCiDGUBlWMTbFCYyWtpLu5QVwUEL4+e7EEbYNPreASP+iIn/sV5hEvOWGwr4HxVc/thyP9mAAR/v7Igs7gPV32+OqbVxheyIwhgQ+czTP/dQuLqyxpbtZfZ2EbMwoX6SWgIlcJKfCpoEyaZebLbII63SXzhQA0OqLcSLT4YbhsmtBKjZ+IlbxftuFxPsP0MdSCb4fM7X5oKnEHKefrWK8oSh54S6+E5282VQ8cU6x91UHogaPZluWLbrO5EsEbeUFBKBjc09EPJ9Lh27Jf2oStsTCpjTpCNrsAqLkuk0d6kDk4EYkutCoceMYT76N4WB3Y8PZV6p5gMMQ==";

    // please replace it with the sub_account in your json file
    private static final String ISS  = "101783233";

    // please replace it with the key_id in your json file
    private static final String KID  = "18366af0b4b44dd8bb4a77184d04704f";

    private static final String AUD  = "https://oauth-login.cloud.huawei.com/oauth2/v3/token";

    public String createJwt() throws NoSuchAlgorithmException, InvalidKeySpecException {
            RSAPrivateKey prk = (RSAPrivateKey) getPrivateKey(PRIVATE_KEY);
            Algorithm algorithm = Algorithm.RSA256(null,prk);
            long iat = System.currentTimeMillis() / 1000;
            long exp = iat + 3600;
            Builder builder =
                    JWT.create()
                            .withIssuer(ISS)
                            .withKeyId(KID)
                            .withAudience(AUD)
                            .withClaim("iat", iat)
                            .withClaim("exp", exp);
            String jwt = builder.sign(algorithm);
            return jwt;
    }

    private PrivateKey getPrivateKey(String key) throws NoSuchAlgorithmException, InvalidKeySpecException {
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(decodeBase64(key));
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        return privateKey;
    }

    private byte[] decodeBase64(String key) {
        return Base64.decodeBase64(key.getBytes(DEFAULT_CHARSET));
    }

    public static void main(String args[]) throws InvalidKeySpecException, NoSuchAlgorithmException {
        JsonWebTokenFactory jsonWebTokenFactory = new JsonWebTokenFactory();
        System.out.println(jsonWebTokenFactory.createJwt());
    }
}
